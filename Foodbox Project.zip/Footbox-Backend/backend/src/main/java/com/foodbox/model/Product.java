package com.foodbox.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Product {
	@Id
    private long id;                // Unique identifier for the product
    private String name;            // Name of the product
    private String des;             // Description of the product
    private String category;        // Category of the product (e.g., Food, Electronics)
    private float actualPrice;      // Original price of the product
    private float discount;         // Discount percentage applied to the product
    private float price;            // Calculated price after applying the discount
    private String avail;           // Availability status of the product (e.g., In Stock, Out of Stock)
    private String imagepath;       // Path to the product's image
	
    // Constructor with all fields
	public Product(long id, String name, String des, String category, float actualPrice, float discount, float price,
			String avail, String imagepath) {
		super();
		this.id = id;
		this.name = name;
		this.des = des;
		this.category = category;
		this.actualPrice = actualPrice;
		this.discount = discount;
		this.price = price;
		this.avail = avail;
		this.imagepath = imagepath;
	}
    // Default constructor
	public Product() {
		super();
	}
    // Getter and setter methods for each field
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesc() {
		return des;
	}

	public void setDesc(String des) {
		this.des = des;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public float getActualPrice() {
		return actualPrice;
	}

	public void setActualPrice(float actualPrice) {
		this.actualPrice = actualPrice;
	}

	public float getDiscount() {
		return discount;
	}

	public void setDiscount(float discount) {
		this.discount = discount;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getAvail() {
		return avail;
	}

	public void setAvail(String avail) {
		this.avail = avail;
	}

	public String getImagepath() {
		return imagepath;
	}

	public void setImagepath(String imagepath) {
		this.imagepath = imagepath;
	}
	
	
}
