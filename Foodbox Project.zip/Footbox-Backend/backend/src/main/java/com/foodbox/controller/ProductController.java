package com.foodbox.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.foodbox.model.Admin;
import com.foodbox.model.Product;
import com.foodbox.repository.AdminRepository;
import com.foodbox.repository.ProductRepository;
import com.foodbox.exception.ResourceNotFoundException;

@CrossOrigin(origins = "http://localhost:4200", allowedHeaders = "*")
@RestController
public class ProductController {
	// Autowired repositories
	@Autowired
	private ProductRepository productRepository;

	@Autowired
	AdminRepository adminRepository;
    // Get all products for Admin
	@GetMapping("/products/Admin")
	public List<Product> getAdminProducts() {
		return productRepository.findAll();
	}
    // Get all products for customers
	@GetMapping("/products/cust")
	public List<Product> getAllProducts() {
        // Check if products are available in the database
		List<Product> prodList = productRepository.findIfAvail();
        // If no products are available, create an admin account and fetch products again
		if (prodList.isEmpty()) {
			List<Admin> adminList = adminRepository.findAll();
			if (adminList.isEmpty()) {
				adminRepository.save(new Admin("admin", "password"));
			}
			prodList = productRepository.findIfAvail();
		}
		return prodList;
	}
    // Utility method to add a product if the product list is empty
	public void addProdIfEmpty(Product product) {
		int min = 10000;
		int max = 99999;
		int b = (int) (Math.random() * (max - min + 1) + min);
		product.setId(b);
        // Calculate price after discount
		float temp = (product.getActualPrice()) * (product.getDiscount() / 100);
		float price = product.getActualPrice() - temp;
		product.setPrice(price);
        // Save the product to the repository
		productRepository.save(product);
	}
    // Add a new product
	@PostMapping("/products")
	public Product addProduct(@RequestBody Product product) {
        // Generating a random ID for the product
		int min = 10000;
		int max = 99999;
		int b = (int) (Math.random() * (max - min + 1) + min);
		product.setId(b);
        // Calculate price after discount
		float temp = (product.getActualPrice()) * (product.getDiscount() / 100);
		float price = product.getActualPrice() - temp;
		product.setPrice(price);
		return productRepository.save(product);
	}
    // Update a product
	@PutMapping("/products/{id}")
	public ResponseEntity<Product> updateProduct(@PathVariable Long id, @RequestBody Product productDetails) {
        // Find the product by ID
		Product product = productRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee Not Found with " + id));
		product.setName(productDetails.getName());
		product.setDesc(productDetails.getDesc());
		product.setCategory(productDetails.getCategory());
		product.setImagepath(productDetails.getImagepath());
		product.setActualPrice(productDetails.getActualPrice());
		product.setDiscount(productDetails.getDiscount());
		product.setAvail(productDetails.getAvail());
        // Calculate price after discount
		float temp = (product.getActualPrice()) * (product.getDiscount() / 100);
		float price = product.getActualPrice() - temp;
		product.setPrice(price);
        // Save the updated product to the repository
		Product updatedProd = productRepository.save(product);
		return ResponseEntity.ok(updatedProd);

	}
    // Delete a product
	@DeleteMapping("/products/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteProduct(@PathVariable Long id) {
        // Find the product by ID
		Product product = productRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Product Not Found with " + id));
		productRepository.delete(product);        // Delete the product from the repository
        // Create a response map indicating successful deletion
		Map<String, Boolean> map = new HashMap<>();
		map.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(map);
	}
    // Get product by ID
	@GetMapping("products/{id}")
	public ResponseEntity<Product> getProductById(@PathVariable long id) {
		Product product = productRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Product Not Found with " + id));
		return ResponseEntity.ok(product);        // Return the product in the response
	}

    // Search for products by keyword
	@GetMapping("products/search/{keyword}")
	public List<Product> getSearchProducts(@PathVariable String keyword) {
		return productRepository.homeSearch(keyword);
	}

	@GetMapping("products/Veg")     // Get all vegetarian products
	public List<Product> getVeg() {
		return productRepository.getVeg();
	}

	@GetMapping("products/NonVeg")
	public List<Product> getNonVeg() {
		return productRepository.getNonVeg();
	}

	@GetMapping("products/Dessert")
	public List<Product> getDessert() {
		return productRepository.getDessert();
	}

	
	
}