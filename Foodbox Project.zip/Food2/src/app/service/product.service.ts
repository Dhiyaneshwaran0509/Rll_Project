// Importing necessary modules and classes from Angular and custom model
import { Product } from './../model/product';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core'; // Importing Injectable decorator from Angular
import { BehaviorSubject,Observable } from 'rxjs'; // Importing BehaviorSubject and Observable from RxJS

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  getDesserts() {
    throw new Error('Method not implemented.');
  }
    // Creating a BehaviorSubject to handle login status
  public login = new BehaviorSubject<any>([]);
  // Defining the base URL for API endpoints
  private baseURL = "http://localhost:8080/products";
  //private adminURL= "http://localhost:8080/AdminProducts";
  constructor(private httpClient: HttpClient) { }
  // Method to get the current login status as an Observable
  getLogin(){
    return this.login.asObservable();
  }
  // Method to fetch a list of products for customers
  getProductList():Observable<Product[]>{
    return this.httpClient.get<Product[]>(`${this.baseURL}/cust`);
  }

  public getProductById(id : number) : Observable<Product> {
    return this.httpClient.get<Product>(`${this.baseURL}/${id}`);
  }
  // Method to search for products based on a keyword
  public getProductSearch(keyword:string):Observable<Product[]>{
    return this.httpClient.get<Product[]>(`${this.baseURL}/search/${keyword}`);
  }

  getVeg():Observable<Product[]>{
    return this.httpClient.get<Product[]>(`${this.baseURL}/Veg`);
  }

  getnonVeg():Observable<Product[]>{
    return this.httpClient.get<Product[]>(`${this.baseURL}/NonVeg`);
  }

  getDessert():Observable<Product[]>{
    return this.httpClient.get<Product[]>(`${this.baseURL}/Dessert`);
  }

  // Method to fetch the full list of products for admin
  getFullProductList():Observable<Product[]>{
    return this.httpClient.get<Product[]>(`${this.baseURL}/Admin`);
  }
  // Method to add a new product
  addProduct(product:Product):Observable<Object>{
    return this.httpClient.post(`${this.baseURL}`,product);
  }

  updateProduct(id:number,product:Product):Observable<Object>{
    return this.httpClient.put<Product>(`${this.baseURL}/${id}`,product);
  }

  deleteProduct(id:number):Observable<Product>{
    return this.httpClient.delete<Product>(`${this.baseURL}/${id}`);
  }
}
